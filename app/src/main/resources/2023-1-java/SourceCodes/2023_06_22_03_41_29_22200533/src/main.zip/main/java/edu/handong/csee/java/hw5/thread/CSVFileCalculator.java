package edu.handong.csee.java.hw5.thread;

import java.util.ArrayList;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import org.apache.commons.cli.Options;
import org.apache.commons.csv.CSVFormat;
import org.apache.commons.csv.CSVRecord;
import org.apache.commons.csv.CSVParser;
import org.apache.commons.csv.CSVPrinter;

import edu.handong.csee.java.hw5.clioptions.OptionHandler;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class CSVFileCalculator implements Runnable {

	private static int row;


	
	@Override
	public void run() {
		// TODO Auto-generated method stub
		
		
		
		
	}
	
	public ArrayList<ArrayList<String>>readCSV(String filePath){
		ArrayList<ArrayList<String>> data = new ArrayList<>();

        try (CSVParser parser = CSVFormat.DEFAULT.parse(new FileReader(filePath))) {
            for (CSVRecord record : parser) {
                ArrayList<String> rowData = new ArrayList<>();
                for (String value : record) {
                    rowData.add(value);
                }
                data.add(rowData);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        return data;
		
	}
	
	public void writeCSV(String filePath, ArrayList<ArrayList<String>> csvData) {
		try (FileWriter fileWriter = new FileWriter(filePath);
	             CSVPrinter csvPrinter = new CSVPrinter(fileWriter, CSVFormat.DEFAULT)) {

	            for (ArrayList<String> row : csvData) {
	                csvPrinter.printRecord(row);
	            }

	            csvPrinter.flush();
	        } catch (IOException e) {
	            e.printStackTrace();
	        }
		
		System.out.println("---!!!---");
	}
	


	

	

}
